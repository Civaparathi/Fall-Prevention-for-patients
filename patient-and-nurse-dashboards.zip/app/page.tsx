'use client';

import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Stethoscope, Users } from 'lucide-react';

export default function Home() {
  const router = useRouter();

  return (
    <main className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex items-center justify-center p-4">
      <Card className="w-full max-w-lg bg-slate-800 border-slate-700">
        <CardHeader className="text-center">
          <CardTitle className="text-3xl text-white mb-2">ICU Monitoring System</CardTitle>
          <p className="text-slate-400 text-sm">Select your dashboard to continue</p>
        </CardHeader>
        <CardContent className="grid grid-cols-2 gap-4">
          <Button
            onClick={() => router.push('/nurse-dashboard')}
            className="h-32 flex flex-col items-center justify-center gap-3 bg-blue-600 hover:bg-blue-700 text-white"
          >
            <Stethoscope size={40} />
            <span className="font-semibold">Nurse Dashboard</span>
          </Button>
          <Button
            onClick={() => router.push('/patient-dashboard')}
            className="h-32 flex flex-col items-center justify-center gap-3 bg-green-600 hover:bg-green-700 text-white"
          >
            <Users size={40} />
            <span className="font-semibold">Patient Dashboard</span>
          </Button>
        </CardContent>
      </Card>
    </main>
  );
}
