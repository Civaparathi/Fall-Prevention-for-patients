'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { LogOut, AlertTriangle, Clock } from 'lucide-react';
import AlertCard from '@/components/alert-card';
import PatientBedCard from '@/components/patient-bed-card';

interface User {
  id: string;
  username: string;
  role: string;
  ward: string;
  name: string;
}

interface AlertData {
  id: string;
  patientId: string;
  patientName: string;
  bedNumber: number;
  ward: string;
  type: 'fall' | 'gait_anomaly' | 'critical_condition';
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  timestamp: number;
  acknowledged: boolean;
  acknowledgedBy?: string;
  details?: any;
}

interface Patient {
  id: string;
  name: string;
  bedNumber: number;
  ward: string;
  currentStatus: 'stable' | 'critical' | 'recovering';
}

export default function NurseDashboard() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [alerts, setAlerts] = useState<AlertData[]>([]);
  const [patients, setPatients] = useState<Patient[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterAcknowledged, setFilterAcknowledged] = useState(false);

  const userData = {
    ward: 'ICU',
  };

  useEffect(() => {
    // Set default nurse user for demo
    const defaultUser: User = {
      id: 'nurse_001',
      username: 'nurse_icu',
      role: 'nurse',
      ward: 'ICU',
      name: 'Nurse ICU',
    };

    setUser(defaultUser);
    setLoading(false);

    // Load patients and alerts
    loadPatients(userData.ward);
    loadAlerts(userData.ward);

    // Poll for updates every 3 seconds
    const pollInterval = setInterval(() => {
      loadAlerts(userData.ward);
    }, 3000);

    return () => clearInterval(pollInterval);
  }, [router]);

  const loadPatients = async (ward: string) => {
    try {
      const response = await fetch(`/api/patients?ward=${encodeURIComponent(ward)}`);
      const data = await response.json();
      if (data.patients) {
        setPatients(data.patients);
      }
    } catch (error) {
      console.error('[v0] Error loading patients:', error);
    }
  };

  const loadAlerts = async (ward: string) => {
    try {
      const response = await fetch(`/api/alerts?ward=${encodeURIComponent(ward)}`);
      const data = await response.json();
      if (data.alerts) {
        setAlerts(data.alerts);
      }
    } catch (error) {
      console.error('[v0] Error loading alerts:', error);
    }
  };

  const handleAcknowledgeAlert = async (alertId: string, nurseName: string) => {
    try {
      const response = await fetch('/api/alerts', {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ alertId, nurseName }),
      });

      if (response.ok) {
        // Reload alerts
        if (user) {
          loadAlerts(user.ward);
        }
      }
    } catch (error) {
      console.error('[v0] Error acknowledging alert:', error);
    }
  };

  const handleLogout = () => {
    localStorage.removeItem('user');
    router.push('/');
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-900">
        <div className="text-slate-300">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  const activeAlerts = alerts.filter((a) => !a.acknowledged);
  const acknowledgedAlerts = alerts.filter((a) => a.acknowledged);

  const criticalAlerts = activeAlerts.filter((a) => a.severity === 'critical');
  const highAlerts = activeAlerts.filter((a) => a.severity === 'high');

  // Map alerts to patients for bed display
  const patientAlertsMap = new Map<string, AlertData[]>();
  alerts.forEach((alert) => {
    if (!patientAlertsMap.has(alert.patientId)) {
      patientAlertsMap.set(alert.patientId, []);
    }
    patientAlertsMap.get(alert.patientId)!.push(alert);
  });

  return (
    <div className="min-h-screen bg-slate-900 p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">Nurse Dashboard</h1>
            <p className="text-slate-400 mt-1">
              <span className="font-semibold">{user.name}</span> • Ward: {user.ward}
            </p>
          </div>
          <Button onClick={() => router.push('/')} variant="outline" className="gap-2 bg-transparent">
            <LogOut className="w-4 h-4" />
            Back to Home
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto space-y-6">
        {/* Alert Summary */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <Card className="bg-slate-800 border-slate-700">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-white">{activeAlerts.length}</div>
                <p className="text-sm text-slate-400 mt-1">Active Alerts</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-red-950/50 border-red-500/50">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-red-300">{criticalAlerts.length}</div>
                <p className="text-sm text-red-400 mt-1">Critical Alerts</p>
              </div>
            </CardContent>
          </Card>
          <Card className="bg-orange-950/50 border-orange-500/50">
            <CardContent className="pt-6">
              <div className="text-center">
                <div className="text-3xl font-bold text-orange-300">{highAlerts.length}</div>
                <p className="text-sm text-orange-400 mt-1">High Priority</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Critical Alert Banner */}
        {criticalAlerts.length > 0 && (
          <Alert className="border-red-500 bg-red-950 animate-pulse">
            <AlertTriangle className="h-5 w-5 text-red-400" />
            <AlertDescription className="text-red-200 font-semibold">
              {criticalAlerts.length} CRITICAL ALERT{criticalAlerts.length !== 1 ? 'S' : ''} -
              Immediate attention required!
            </AlertDescription>
          </Alert>
        )}

        {/* Tabs for different views */}
        <Tabs defaultValue="alerts" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-slate-800">
            <TabsTrigger value="alerts">
              Active Alerts ({activeAlerts.length})
            </TabsTrigger>
            <TabsTrigger value="beds">Patient Beds</TabsTrigger>
            <TabsTrigger value="history">
              <Clock className="w-4 h-4 mr-2" />
              History ({acknowledgedAlerts.length})
            </TabsTrigger>
          </TabsList>

          {/* Active Alerts Tab */}
          <TabsContent value="alerts" className="space-y-4 mt-6">
            {activeAlerts.length === 0 ? (
              <Card className="bg-slate-800 border-slate-700">
                <CardContent className="pt-6 text-center text-slate-400">
                  <p>No active alerts</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-4">
                {/* Critical and High Priority */}
                {[...criticalAlerts, ...highAlerts].length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold text-red-300 mb-3">
                      Priority Alerts
                    </h3>
                    <div className="space-y-3">
                      {[...criticalAlerts, ...highAlerts].map((alert) => (
                        <AlertCard
                          key={alert.id}
                          {...alert}
                          onAcknowledge={handleAcknowledgeAlert}
                        />
                      ))}
                    </div>
                  </div>
                )}

                {/* Medium and Low Priority */}
                {activeAlerts.filter((a) => a.severity === 'medium' || a.severity === 'low')
                  .length > 0 && (
                  <div>
                    <h3 className="text-lg font-semibold text-yellow-300 mb-3">
                      Other Alerts
                    </h3>
                    <div className="space-y-3">
                      {activeAlerts
                        .filter((a) => a.severity === 'medium' || a.severity === 'low')
                        .map((alert) => (
                          <AlertCard
                            key={alert.id}
                            {...alert}
                            onAcknowledge={handleAcknowledgeAlert}
                          />
                        ))}
                    </div>
                  </div>
                )}
              </div>
            )}
          </TabsContent>

          {/* Patient Beds Tab */}
          <TabsContent value="beds" className="space-y-4 mt-6">
            {patients.length === 0 ? (
              <Card className="bg-slate-800 border-slate-700">
                <CardContent className="pt-6 text-center text-slate-400">
                  <p>No patients assigned to this ward</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                {patients.map((patient) => {
                  const patientAlerts = patientAlertsMap.get(patient.id) || [];
                  const activePatientAlerts = patientAlerts.filter((a) => !a.acknowledged);
                  return (
                    <PatientBedCard
                      key={patient.id}
                      patientId={patient.id}
                      patientName={patient.name}
                      bedNumber={patient.bedNumber}
                      status={patient.currentStatus}
                      hasActiveAlert={activePatientAlerts.length > 0}
                      alertCount={activePatientAlerts.length}
                      lastUpdate={Date.now()}
                    />
                  );
                })}
              </div>
            )}
          </TabsContent>

          {/* Alert History Tab */}
          <TabsContent value="history" className="space-y-4 mt-6">
            {acknowledgedAlerts.length === 0 ? (
              <Card className="bg-slate-800 border-slate-700">
                <CardContent className="pt-6 text-center text-slate-400">
                  <p>No acknowledged alerts yet</p>
                </CardContent>
              </Card>
            ) : (
              <div className="space-y-3">
                {acknowledgedAlerts.map((alert) => (
                  <AlertCard
                    key={alert.id}
                    {...alert}
                    onAcknowledge={handleAcknowledgeAlert}
                  />
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
