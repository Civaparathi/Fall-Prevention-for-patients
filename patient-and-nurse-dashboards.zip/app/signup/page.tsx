import SignupForm from '@/components/signup-form';

export const metadata = {
  title: 'Sign Up - ICU Monitoring System',
  description: 'Create an account for ICU monitoring system',
};

export default function SignupPage() {
  return <SignupForm />;
}
