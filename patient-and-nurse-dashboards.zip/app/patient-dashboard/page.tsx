'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert as UIAlert, AlertDescription } from '@/components/ui/alert';
import { LogOut, AlertTriangle } from 'lucide-react';
import PatientHealthDisplay from '@/components/patient-health-display';
import GyroscopeSimulatorDisplay from '@/components/gyroscope-simulator-display';

interface User {
  id: string;
  username: string;
  role: string;
  ward: string;
  name: string;
  patientId: string;
}

interface Alert {
  id: string;
  type: string;
  severity: string;
  message: string;
  timestamp: number;
}

export default function PatientDashboard() {
  const router = useRouter();
  const [user, setUser] = useState<User | null>(null);
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [metrics, setMetrics] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Set default patient user for demo
    const defaultUser: User = {
      id: 'patient_001',
      username: 'rajesh_p001',
      role: 'patient',
      ward: 'ICU',
      name: 'Rajesh Kumar',
      patientId: 'P001',
    };

    setUser(defaultUser);

    // Load initial metrics
    const initialMetrics = {
      heartRate: 72,
      oxygenLevel: 98,
      temperature: 37.0,
      bloodPressure: '120/80',
      strideLength: 65,
      walkingSpeed: 1.2,
      stepSymmetry: 95,
    };
    setMetrics(initialMetrics);
    setLoading(false);

    // Poll for alerts every 5 seconds
    const alertInterval = setInterval(async () => {
      try {
        const response = await fetch(`/api/alerts?ward=${defaultUser.ward}`);
        const data = await response.json();
        if (data.alerts) {
          // Filter alerts for this patient
          const patientAlerts = data.alerts.filter((a: any) => a.patientId === defaultUser.patientId);
          setAlerts(patientAlerts);
        }
      } catch (error) {
        console.error('[v0] Error fetching alerts:', error);
      }
    }, 5000);

    return () => clearInterval(alertInterval);
  }, [router]);

  const handleLogout = () => {
    router.push('/');
  };

  const handleGaitAnalysis = (analysis: any) => {
    if (analysis.anomalies && analysis.anomalies.length > 0) {
      // Send alert to nurse
      fetch('/api/alerts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientId: user?.patientId,
          patientName: user?.name,
          bedNumber: 101, // Mock bed number
          ward: user?.ward,
          type: 'gait_anomaly',
          severity: analysis.stepSymmetry < 60 ? 'high' : 'medium',
          message: `Gait anomaly detected: ${analysis.anomalies.join(', ')}`,
          timestamp: Date.now(),
          acknowledged: false,
          details: {
            strideLength: analysis.strideLength,
            walkingSpeed: analysis.walkingSpeed,
            stepSymmetry: analysis.stepSymmetry,
            inconsistencies: analysis.anomalies,
          },
        }),
      });
    }
  };

  const handleFallDetected = (fallData: any) => {
    if (fallData.isFalling) {
      // Send critical alert to nurse
      fetch('/api/alerts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientId: user?.patientId,
          patientName: user?.name,
          bedNumber: 101, // Mock bed number
          ward: user?.ward,
          type: 'fall',
          severity: 'critical',
          message: 'PATIENT FALL DETECTED - Immediate assistance required',
          timestamp: Date.now(),
          acknowledged: false,
          details: {
            fallDetected: true,
            heightFromGround: 0.5,
          },
        }),
      });
    }
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-slate-900">
        <div className="text-slate-300">Loading...</div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="min-h-screen bg-slate-900 p-6">
      {/* Header */}
      <div className="max-w-7xl mx-auto mb-8">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-white">Patient Dashboard</h1>
            <p className="text-slate-400 mt-1">
              Welcome, <span className="font-semibold">{user.name}</span> • Ward: {user.ward}
            </p>
          </div>
          <Button onClick={handleLogout} variant="outline" className="gap-2 bg-transparent">
            <LogOut className="w-4 h-4" />
            Back to Home
          </Button>
        </div>
      </div>

      <div className="max-w-7xl mx-auto space-y-6">
        {/* Active Alerts */}
        {alerts.length > 0 && (
          <UIAlert className="border-red-500 bg-red-950">
            <AlertTriangle className="h-4 w-4 text-red-400" />
            <AlertDescription className="text-red-200">
              You have <span className="font-semibold">{alerts.length}</span> active alert
              {alerts.length !== 1 ? 's' : ''} from your care team.
            </AlertDescription>
          </UIAlert>
        )}

        {/* Health Metrics */}
        {metrics && (
          <div>
            <h2 className="text-xl font-bold text-white mb-4">Current Health Metrics</h2>
            <PatientHealthDisplay metrics={metrics} isAlert={alerts.length > 0} />
          </div>
        )}

        {/* Gyroscope Simulator */}
        <div>
          <h2 className="text-xl font-bold text-white mb-4">Movement & Gait Analysis</h2>
          {user && (
            <GyroscopeSimulatorDisplay
              patientId={user.patientId}
              onGaitAnalysis={handleGaitAnalysis}
              onFallDetected={handleFallDetected}
            />
          )}
        </div>

        {/* Active Alerts List */}
        {alerts.length > 0 && (
          <div>
            <h2 className="text-xl font-bold text-white mb-4">Active Alerts</h2>
            <div className="space-y-3">
              {alerts.map((alert) => (
                <Card key={alert.id} className="bg-red-950 border-red-500">
                  <CardContent className="pt-6">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <p className="font-semibold text-red-200">{alert.message}</p>
                        <p className="text-sm text-red-300 mt-1">
                          {new Date(alert.timestamp).toLocaleString()}
                        </p>
                      </div>
                      <span className="inline-block px-3 py-1 bg-red-500 text-white text-xs font-semibold rounded">
                        {alert.severity.toUpperCase()}
                      </span>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
