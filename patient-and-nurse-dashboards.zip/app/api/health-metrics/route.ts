import { initializeDB, addHealthMetrics, getHealthMetricsForPatient } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  try {
    initializeDB();
    const { searchParams } = new URL(req.url);
    const patientId = searchParams.get('patientId');

    if (!patientId) {
      return NextResponse.json(
        { error: 'patientId parameter is required' },
        { status: 400 }
      );
    }

    const metrics = getHealthMetricsForPatient(patientId, 50);
    return NextResponse.json({ metrics });
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    initializeDB();
    const body = await req.json();

    const metrics = addHealthMetrics(body);

    return NextResponse.json({ metrics }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
