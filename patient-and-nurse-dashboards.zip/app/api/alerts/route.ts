import { initializeDB, getAlertsByWard, createAlert, acknowledgeAlert } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  try {
    initializeDB();
    const { searchParams } = new URL(req.url);
    const ward = searchParams.get('ward');
    const acknowledged = searchParams.get('acknowledged');

    if (!ward) {
      return NextResponse.json(
        { error: 'Ward parameter is required' },
        { status: 400 }
      );
    }

    let alerts = getAlertsByWard(ward as any);

    if (acknowledged !== null) {
      const isAcknowledged = acknowledged === 'true';
      alerts = alerts.filter((a) => a.acknowledged === isAcknowledged);
    }

    return NextResponse.json({ alerts: alerts.sort((a, b) => b.timestamp - a.timestamp) });
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function POST(req: NextRequest) {
  try {
    initializeDB();
    const body = await req.json();

    const alert = createAlert(body);

    return NextResponse.json({ alert }, { status: 201 });
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}

export async function PUT(req: NextRequest) {
  try {
    initializeDB();
    const { alertId, nurseName } = await req.json();

    const alert = acknowledgeAlert(alertId, nurseName);

    return NextResponse.json({ alert });
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
