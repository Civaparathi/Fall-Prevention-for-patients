import { initializeDB, getPatientsByWard, findPatientById } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function GET(req: NextRequest) {
  try {
    initializeDB();
    const { searchParams } = new URL(req.url);
    const ward = searchParams.get('ward');
    const patientId = searchParams.get('patientId');

    if (patientId) {
      const patient = findPatientById(patientId);
      if (!patient) {
        return NextResponse.json({ error: 'Patient not found' }, { status: 404 });
      }
      return NextResponse.json({ patient });
    }

    if (!ward) {
      return NextResponse.json(
        { error: 'Ward parameter is required' },
        { status: 400 }
      );
    }

    const patients = getPatientsByWard(ward as any);
    return NextResponse.json({ patients });
  } catch (error) {
    return NextResponse.json({ error: 'Internal server error' }, { status: 500 });
  }
}
