import { initializeDB, findUserByUsername, db, findPatientById } from '@/lib/db';
import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  try {
    initializeDB();
    const { username, password, name, role, ward, patientId } = await req.json();

    // Validate required fields
    if (!username || !password || !name || !role || !ward) {
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      );
    }

    // Check if username already exists
    if (findUserByUsername(username)) {
      return NextResponse.json(
        { error: 'Username already exists' },
        { status: 409 }
      );
    }

    // For patient registration, check if patient exists
    if (role === 'patient' && patientId) {
      const patient = findPatientById(patientId);
      if (!patient) {
        return NextResponse.json(
          { error: 'Patient ID not found in system' },
          { status: 404 }
        );
      }
    }

    // Create new user
    const newUser = {
      id: `U${Date.now()}`,
      username,
      password,
      role: role as 'patient' | 'nurse',
      ward: ward,
      name,
      patientId: role === 'patient' ? patientId : undefined,
    };

    db.users.push(newUser);

    return NextResponse.json({
      success: true,
      user: {
        id: newUser.id,
        username: newUser.username,
        role: newUser.role,
        ward: newUser.ward,
        name: newUser.name,
        patientId: newUser.patientId,
      },
    });
  } catch (error) {
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    );
  }
}
