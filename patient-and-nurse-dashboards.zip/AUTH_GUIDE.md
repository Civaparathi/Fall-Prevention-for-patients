# ICU Monitoring System - Authentication Guide

## Sign In / Login Flow

### Step 1: Access Login Page
- Navigate to the home page (`/`)
- You'll see the Login form with three sections:
  1. Ward Selection dropdown
  2. Username & Password input fields
  3. Demo credentials list

### Step 2: Login Methods

#### Method A: Using Demo Credentials (Quick Test)
1. Click on any demo credential card in the "Demo Credentials" section
2. The username and password will auto-fill
3. Click "Sign In" button
4. You'll be redirected based on your role:
   - **Nurses** → Nurse Dashboard (`/nurse-dashboard`)
   - **Patients** → Patient Dashboard (`/patient-dashboard`)

#### Method B: Manual Login
1. Select your **Ward** from the dropdown
2. Enter your **Username**
3. Enter your **Password**
4. Click "Sign In"
5. On successful login, you'll be redirected to your dashboard

#### Method C: Create New Account (Sign Up)
1. Click "Don't have an account? Sign up here" link at the bottom of login form
2. Fill out the sign-up form:
   - **Full Name**: Your name
   - **Role**: Select "Patient" or "Nurse"
   - **Patient ID**: (Only for patients) Select from hospital patient records
   - **Ward**: Select your assigned ward
   - **Username**: Choose a unique username
   - **Password**: Minimum 6 characters
3. Click "Sign Up" button
4. Account created successfully → Redirect to login page
5. Login with your new credentials

---

## Demo Credentials (For Testing)

### Nurses
```
Ward: ICU
Username: nurse_icu
Password: nurse123

Ward: Operation Theatre
Username: nurse_ot
Password: nurse123

Ward: Normal Ward 1
Username: nurse_ward1
Password: nurse123

Ward: Normal Ward 2
Username: nurse_ward2
Password: nurse123

Ward: Normal Ward 3
Username: nurse_ward3
Password: nurse123
```

### Patients
```
Ward: ICU
Username: rajesh_p001
Password: patient123
Patient ID: P001 - Rajesh Kumar

Ward: ICU
Username: meena_p002
Password: patient123
Patient ID: P002 - Meena Sharma

Ward: Operation Theatre
Username: arjun_p003
Password: patient123
Patient ID: P003 - Arjun Singh

Ward: Normal Ward 1
Username: priya_p004
Password: patient123
Patient ID: P004 - Priya Patel

Ward: Normal Ward 1
Username: vikram_p005
Password: patient123
Patient ID: P005 - Vikram Desai
```

---

## Authentication Architecture

### Login Process
1. User submits username & password
2. API endpoint (`/api/auth/login`) validates credentials
3. Checks if user exists in database
4. Returns user object with role, ward, patient ID (if applicable)
5. User data stored in `localStorage` as "user"
6. Redirect based on role

### Sign Up Process
1. New user fills out registration form
2. API endpoint (`/api/auth/signup`) validates input:
   - Checks if username already exists
   - For patients: Validates patient ID exists in system
   - Validates password length (min 6 characters)
3. Creates new user record in database
4. Returns success → Redirect to login
5. User can now login with new credentials

### Session Management
- User data stored in `localStorage` (key: "user")
- Stored data includes:
  - User ID
  - Username
  - Role (patient/nurse)
  - Ward
  - Name
  - Patient ID (if applicable)

### Dashboard Access
- **Patient Dashboard** (`/patient-dashboard`)
  - Displays personal health metrics
  - Shows gyroscope-based gait analysis
  - Real-time heart rate, oxygen, temperature
  - Detects falls and walking anomalies

- **Nurse Dashboard** (`/nurse-dashboard`)
  - Shows all patients in assigned ward
  - Displays real-time alerts and notifications
  - Allows acknowledging patient alerts
  - Filters alerts by severity and type

---

## Error Messages

| Error | Cause | Solution |
|-------|-------|----------|
| "Invalid username or password" | Wrong credentials | Check username and password, or sign up for new account |
| "Username already exists" | During sign up - username taken | Choose a different username |
| "Patient ID not found in system" | During sign up - invalid patient ID | Select from available patient IDs |
| "Missing required fields" | Incomplete form | Fill all required fields |
| "An error occurred" | Server error | Try again or refresh page |

---

## Security Notes

⚠️ **Demo System**: This is a demonstration system using plain-text passwords for testing purposes. 

In production, implement:
- Password hashing (bcrypt)
- Secure session tokens (JWT)
- HTTPS encryption
- Rate limiting on login attempts
- Password reset functionality
- Two-factor authentication (2FA)
- Role-based access control (RBAC)
