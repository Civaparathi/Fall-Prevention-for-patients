// Mock database with types and initial data
export type Ward = 'ICU' | 'Operation Theatre' | 'Normal Ward 1' | 'Normal Ward 2' | 'Normal Ward 3';

export type User = {
  id: string;
  username: string;
  password: string;
  role: 'patient' | 'nurse';
  ward: Ward;
  patientId?: string; // For nurses, the patient they're monitoring (if patient role)
  name: string;
};

export type Patient = {
  id: string;
  name: string;
  bedNumber: number;
  ward: Ward;
  dateOfAdmission: string;
  medicalHistory: string;
  currentStatus: 'stable' | 'critical' | 'recovering';
};

export type Alert = {
  id: string;
  patientId: string;
  patientName: string;
  bedNumber: number;
  ward: Ward;
  type: 'fall' | 'gait_anomaly' | 'critical_condition';
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  timestamp: number;
  acknowledged: boolean;
  acknowledgedBy?: string;
  acknowledgedAt?: number;
  details: {
    fallDetected?: boolean;
    heightFromGround?: number;
    gaitIssue?: string;
    heartRate?: number;
    oxygenLevel?: number;
    strideLength?: number;
    walkingSpeed?: number;
    stepSymmetry?: number;
    inconsistencies?: string[];
  };
};

export type HealthMetrics = {
  id: string;
  patientId: string;
  timestamp: number;
  heartRate: number;
  oxygenLevel: number;
  bloodPressure: string;
  temperature: number;
  gyroscopeData: {
    x: number;
    y: number;
    z: number;
  };
  strideLength: number;
  walkingSpeed: number;
  stepSymmetry: number;
};

// In-memory database
export const db = {
  users: [] as User[],
  patients: [] as Patient[],
  alerts: [] as Alert[],
  healthMetrics: [] as HealthMetrics[],
};

// Initialize with mock data
export function initializeDB() {
  // Patients
  db.patients = [
    {
      id: 'P001',
      name: 'Rajesh Kumar',
      bedNumber: 101,
      ward: 'ICU',
      dateOfAdmission: '2024-01-15',
      medicalHistory: 'Diabetes, Hypertension',
      currentStatus: 'stable',
    },
    {
      id: 'P002',
      name: 'Meena Sharma',
      bedNumber: 102,
      ward: 'ICU',
      dateOfAdmission: '2024-01-16',
      medicalHistory: 'Post-operative recovery',
      currentStatus: 'recovering',
    },
    {
      id: 'P003',
      name: 'Arjun Singh',
      bedNumber: 201,
      ward: 'Operation Theatre',
      dateOfAdmission: '2024-01-17',
      medicalHistory: 'Scheduled surgery',
      currentStatus: 'stable',
    },
    {
      id: 'P004',
      name: 'Priya Patel',
      bedNumber: 301,
      ward: 'Normal Ward 1',
      dateOfAdmission: '2024-01-18',
      medicalHistory: 'General admission',
      currentStatus: 'stable',
    },
    {
      id: 'P005',
      name: 'Vikram Desai',
      bedNumber: 302,
      ward: 'Normal Ward 1',
      dateOfAdmission: '2024-01-19',
      medicalHistory: 'Recovery phase',
      currentStatus: 'recovering',
    },
  ];

  // Users - Patients
  db.users = [
    {
      id: 'U001',
      username: 'rajesh_p001',
      password: 'patient123',
      role: 'patient',
      ward: 'ICU',
      patientId: 'P001',
      name: 'Rajesh Kumar',
    },
    {
      id: 'U002',
      username: 'meena_p002',
      password: 'patient123',
      role: 'patient',
      ward: 'ICU',
      patientId: 'P002',
      name: 'Meena Sharma',
    },
    {
      id: 'U003',
      username: 'arjun_p003',
      password: 'patient123',
      role: 'patient',
      ward: 'Operation Theatre',
      patientId: 'P003',
      name: 'Arjun Singh',
    },
    {
      id: 'U004',
      username: 'priya_p004',
      password: 'patient123',
      role: 'patient',
      ward: 'Normal Ward 1',
      patientId: 'P004',
      name: 'Priya Patel',
    },
    {
      id: 'U005',
      username: 'vikram_p005',
      password: 'patient123',
      role: 'patient',
      ward: 'Normal Ward 1',
      patientId: 'P005',
      name: 'Vikram Desai',
    },
    // Nurses
    {
      id: 'N001',
      username: 'nurse_icu',
      password: 'nurse123',
      role: 'nurse',
      ward: 'ICU',
      name: 'Dr. Nurse ICU',
    },
    {
      id: 'N002',
      username: 'nurse_ot',
      password: 'nurse123',
      role: 'nurse',
      ward: 'Operation Theatre',
      name: 'Dr. Nurse OT',
    },
    {
      id: 'N003',
      username: 'nurse_ward1',
      password: 'nurse123',
      role: 'nurse',
      ward: 'Normal Ward 1',
      name: 'Dr. Nurse Ward 1',
    },
    {
      id: 'N004',
      username: 'nurse_ward2',
      password: 'nurse123',
      role: 'nurse',
      ward: 'Normal Ward 2',
      name: 'Dr. Nurse Ward 2',
    },
    {
      id: 'N005',
      username: 'nurse_ward3',
      password: 'nurse123',
      role: 'nurse',
      ward: 'Normal Ward 3',
      name: 'Dr. Nurse Ward 3',
    },
  ];
}

// Helper functions
export function findUserByUsername(username: string) {
  return db.users.find((u) => u.username === username);
}

export function findPatientById(patientId: string) {
  return db.patients.find((p) => p.id === patientId);
}

export function getPatientsByWard(ward: Ward) {
  return db.patients.filter((p) => p.ward === ward);
}

export function getAlertsByWard(ward: Ward) {
  return db.alerts.filter((a) => a.ward === ward);
}

export function createAlert(alert: Omit<Alert, 'id'>) {
  const newAlert: Alert = {
    ...alert,
    id: `ALERT_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
  };
  db.alerts.push(newAlert);
  return newAlert;
}

export function acknowledgeAlert(alertId: string, nurseName: string) {
  const alert = db.alerts.find((a) => a.id === alertId);
  if (alert) {
    alert.acknowledged = true;
    alert.acknowledgedBy = nurseName;
    alert.acknowledgedAt = Date.now();
  }
  return alert;
}

export function addHealthMetrics(metrics: Omit<HealthMetrics, 'id'>) {
  const newMetrics: HealthMetrics = {
    ...metrics,
    id: `METRICS_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
  };
  db.healthMetrics.push(newMetrics);
  return newMetrics;
}

export function getHealthMetricsForPatient(patientId: string, limit: number = 50) {
  return db.healthMetrics
    .filter((m) => m.patientId === patientId)
    .sort((a, b) => b.timestamp - a.timestamp)
    .slice(0, limit);
}
