// Gyroscope data simulator for realistic walking patterns
// Based on typical human gait analysis

export interface GyroscopeReading {
  x: number;
  y: number;
  z: number;
  timestamp: number;
}

export interface GaitAnalysis {
  strideLength: number; // in cm
  walkingSpeed: number; // in m/s
  stepSymmetry: number; // 0-100 (100 = perfect symmetry)
  gaitPhase: 'stance' | 'swing'; // walking phase
  isNormalGait: boolean;
  anomalies: string[];
}

// Normal gait patterns - realistic gyroscope readings during walking
const NORMAL_GAIT_CYCLE = [
  // Stance phase (60% of cycle)
  { x: 0.1, y: 0.05, z: 0.02 },
  { x: 0.15, y: 0.08, z: 0.03 },
  { x: 0.12, y: 0.06, z: 0.025 },
  { x: 0.08, y: 0.04, z: 0.015 },
  // Swing phase (40% of cycle)
  { x: -0.1, y: 0.12, z: -0.05 },
  { x: -0.15, y: 0.18, z: -0.08 },
  { x: -0.12, y: 0.15, z: -0.06 },
];

// Abnormal gait patterns
const FALL_DETECTION_PATTERN = [
  { x: 0.5, y: 0.5, z: 0.8 }, // Sudden acceleration
  { x: 0.8, y: 0.9, z: 1.2 }, // High acceleration (falling)
  { x: 1.0, y: 1.0, z: 1.5 }, // Peak acceleration
  { x: 0.2, y: 0.1, z: 0.05 }, // Impact/ground contact
];

const UNSTEADY_GAIT_PATTERN = [
  { x: 0.25, y: 0.15, z: 0.08 },
  { x: 0.1, y: 0.35, z: 0.12 },
  { x: 0.3, y: 0.05, z: 0.15 },
  { x: 0.05, y: 0.25, z: 0.02 },
];

export class GyroscopeSimulator {
  private normalWalkingCycle = 0;
  private timestamp = 0;
  private isSimulatingFall = false;
  private fallStartTime = 0;
  private gaitQuality = 'normal'; // 'normal', 'unsteady', 'falling'

  constructor() {
    this.timestamp = Date.now();
  }

  /**
   * Generate simulated gyroscope readings
   */
  generateReading(scenario: 'normal' | 'unsteady' | 'falling' = 'normal'): GyroscopeReading {
    let reading: { x: number; y: number; z: number };

    if (scenario === 'falling') {
      const pattern = FALL_DETECTION_PATTERN;
      const index = Math.floor(Math.random() * pattern.length);
      reading = {
        x: pattern[index].x + (Math.random() - 0.5) * 0.2,
        y: pattern[index].y + (Math.random() - 0.5) * 0.2,
        z: pattern[index].z + (Math.random() - 0.5) * 0.3,
      };
    } else if (scenario === 'unsteady') {
      const pattern = UNSTEADY_GAIT_PATTERN;
      const index = Math.floor(this.normalWalkingCycle) % pattern.length;
      reading = {
        x: pattern[index].x + (Math.random() - 0.5) * 0.15,
        y: pattern[index].y + (Math.random() - 0.5) * 0.15,
        z: pattern[index].z + (Math.random() - 0.5) * 0.1,
      };
      this.normalWalkingCycle += 0.5;
    } else {
      // Normal gait
      const index = Math.floor(this.normalWalkingCycle) % NORMAL_GAIT_CYCLE.length;
      const basePattern = NORMAL_GAIT_CYCLE[index];
      reading = {
        x: basePattern.x + (Math.random() - 0.5) * 0.08,
        y: basePattern.y + (Math.random() - 0.5) * 0.08,
        z: basePattern.z + (Math.random() - 0.5) * 0.05,
      };
      this.normalWalkingCycle += 0.5;
    }

    this.timestamp += 50; // 50ms between readings

    return {
      x: Math.round(reading.x * 1000) / 1000,
      y: Math.round(reading.y * 1000) / 1000,
      z: Math.round(reading.z * 1000) / 1000,
      timestamp: this.timestamp,
    };
  }

  /**
   * Analyze gait from gyroscope readings
   */
  analyzeGait(readings: GyroscopeReading[]): GaitAnalysis {
    if (readings.length < 3) {
      return {
        strideLength: 0,
        walkingSpeed: 0,
        stepSymmetry: 100,
        gaitPhase: 'stance',
        isNormalGait: true,
        anomalies: [],
      };
    }

    const anomalies: string[] = [];
    let totalAcceleration = 0;

    // Detect abnormal acceleration (potential fall)
    for (const reading of readings) {
      const magnitude = Math.sqrt(reading.x ** 2 + reading.y ** 2 + reading.z ** 2);
      totalAcceleration += magnitude;

      if (magnitude > 0.8) {
        anomalies.push('High acceleration detected');
      }
    }

    const avgAcceleration = totalAcceleration / readings.length;

    // Analyze step symmetry (compare x-axis variations between steps)
    const xValues = readings.map((r) => r.x);
    const yValues = readings.map((r) => r.y);

    let xVariation = 0;
    let yVariation = 0;

    for (let i = 1; i < xValues.length; i++) {
      xVariation += Math.abs(xValues[i] - xValues[i - 1]);
      yVariation += Math.abs(yValues[i] - yValues[i - 1]);
    }

    // Calculate step symmetry (0-100 where 100 is perfect)
    const symmetryFactor = Math.min(100, 100 - Math.abs(xVariation - yVariation) * 50);

    // Estimate stride length (proportional to forward movement)
    const strideLength = Math.abs(avgAcceleration) * 50 + 40; // 40-90cm estimate

    // Estimate walking speed (based on acceleration patterns)
    const walkingSpeed = Math.min(2.0, Math.max(0.5, avgAcceleration * 2.5)); // 0.5-2.0 m/s

    // Detect gait anomalies
    if (symmetryFactor < 60) {
      anomalies.push('Asymmetric gait detected');
    }

    if (strideLength < 35 || strideLength > 95) {
      anomalies.push('Abnormal stride length');
    }

    if (walkingSpeed < 0.5 || walkingSpeed > 1.8) {
      anomalies.push('Abnormal walking speed');
    }

    // Analyze axis variations for specific issues
    const maxZ = Math.max(...readings.map((r) => Math.abs(r.z)));
    if (maxZ > 0.5) {
      anomalies.push('Excessive vertical movement - possible imbalance');
    }

    return {
      strideLength: Math.round(strideLength),
      walkingSpeed: Math.round(walkingSpeed * 100) / 100,
      stepSymmetry: Math.round(symmetryFactor),
      gaitPhase: readings[readings.length - 1].z > 0 ? 'swing' : 'stance',
      isNormalGait: anomalies.length === 0,
      anomalies,
    };
  }

  /**
   * Detect if a fall is happening based on gyroscope readings
   */
  detectFall(readings: GyroscopeReading[]): {
    isFalling: boolean;
    confidenceScore: number;
    description: string;
  } {
    if (readings.length === 0) {
      return { isFalling: false, confidenceScore: 0, description: 'No data' };
    }

    let maxAcceleration = 0;
    let rapidDeceleration = false;

    for (let i = 0; i < readings.length; i++) {
      const magnitude = Math.sqrt(
        readings[i].x ** 2 + readings[i].y ** 2 + readings[i].z ** 2
      );
      maxAcceleration = Math.max(maxAcceleration, magnitude);

      // Detect rapid deceleration (sudden stop after high acceleration)
      if (i > 0) {
        const prevMagnitude = Math.sqrt(
          readings[i - 1].x ** 2 + readings[i - 1].y ** 2 + readings[i - 1].z ** 2
        );
        if (prevMagnitude > 0.6 && magnitude < 0.2) {
          rapidDeceleration = true;
        }
      }
    }

    const isFalling = maxAcceleration > 0.8 && rapidDeceleration;
    const confidenceScore = Math.min(100, maxAcceleration * 80);

    let description = 'No fall detected';
    if (isFalling) {
      description = 'FALL DETECTED - Patient has fallen';
    } else if (maxAcceleration > 0.6) {
      description = 'High movement detected - possible instability';
    }

    return {
      isFalling,
      confidenceScore: Math.round(confidenceScore),
      description,
    };
  }

  /**
   * Generate a realistic dataset of gyroscope readings
   */
  generateDataset(
    duration: number = 5000,
    interval: number = 50,
    scenario: 'normal' | 'unsteady' | 'falling' = 'normal'
  ): GyroscopeReading[] {
    const readings: GyroscopeReading[] = [];
    const numReadings = Math.floor(duration / interval);

    for (let i = 0; i < numReadings; i++) {
      readings.push(this.generateReading(scenario));
    }

    return readings;
  }
}

/**
 * Generate a realistic patient gait dataset
 */
export function generatePatientGaitDataset() {
  const simulator = new GyroscopeSimulator();

  // Normal walking data
  const normalWalk = simulator.generateDataset(3000, 50, 'normal');

  // Analysis
  const analysis = simulator.analyzeGait(normalWalk);

  return {
    readings: normalWalk,
    analysis,
  };
}

/**
 * Generate abnormal gait for testing alert system
 */
export function generateAbnormalGaitDataset(type: 'fall' | 'unsteady' = 'unsteady') {
  const simulator = new GyroscopeSimulator();
  const readings = simulator.generateDataset(2000, 50, type);
  const analysis = simulator.analyzeGait(readings);
  const fallDetection = simulator.detectFall(readings);

  return {
    readings,
    analysis,
    fallDetection,
  };
}
