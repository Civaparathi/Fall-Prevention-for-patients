'use client';

import React from "react"

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertCircle } from 'lucide-react';

type Ward = 'ICU' | 'Operation Theatre' | 'Normal Ward 1' | 'Normal Ward 2' | 'Normal Ward 3';

export default function LoginForm() {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [ward, setWard] = useState<Ward>('ICU');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const router = useRouter();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError('');

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password }),
      });

      const data = await response.json();

      if (!response.ok) {
        setError(data.error || 'Login failed');
        setLoading(false);
        return;
      }

      // Store user data in localStorage
      localStorage.setItem('user', JSON.stringify(data.user));

      // Redirect based on role
      if (data.user.role === 'patient') {
        router.push('/patient-dashboard');
      } else {
        router.push('/nurse-dashboard');
      }
    } catch (err) {
      setError('An error occurred. Please try again.');
      setLoading(false);
    }
  };

  // Demo credentials
  const demoCredentials = [
    { username: 'nurse_icu', password: 'nurse123', role: 'Nurse - ICU' },
    { username: 'nurse_ward1', password: 'nurse123', role: 'Nurse - Ward 1' },
    { username: 'rajesh_p001', password: 'patient123', role: 'Patient - ICU' },
    { username: 'priya_p004', password: 'patient123', role: 'Patient - Ward 1' },
  ];

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 p-4">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-2">ICU Monitoring System</h1>
          <p className="text-slate-400">Patient & Nurse Dashboard</p>
        </div>

        <Card className="border-slate-700 bg-slate-800 shadow-2xl">
          <CardHeader>
            <CardTitle className="text-white">Login</CardTitle>
            <CardDescription className="text-slate-400">
              Enter your credentials to access your dashboard
            </CardDescription>
          </CardHeader>
          <CardContent>
            {error && (
              <Alert className="mb-4 border-red-500 bg-red-950">
                <AlertCircle className="h-4 w-4 text-red-400" />
                <AlertDescription className="text-red-200">{error}</AlertDescription>
              </Alert>
            )}

            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-200 mb-2">
                  Ward
                </label>
                <Select value={ward} onValueChange={(value) => setWard(value as Ward)}>
                  <SelectTrigger className="bg-slate-700 border-slate-600 text-white">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-slate-700 border-slate-600">
                    <SelectItem value="ICU">ICU</SelectItem>
                    <SelectItem value="Operation Theatre">Operation Theatre</SelectItem>
                    <SelectItem value="Normal Ward 1">Normal Ward 1</SelectItem>
                    <SelectItem value="Normal Ward 2">Normal Ward 2</SelectItem>
                    <SelectItem value="Normal Ward 3">Normal Ward 3</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-200 mb-2">
                  Username
                </label>
                <Input
                  type="text"
                  placeholder="Enter your username"
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-500"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-200 mb-2">
                  Password
                </label>
                <Input
                  type="password"
                  placeholder="Enter your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-500"
                />
              </div>

              <Button
                type="submit"
                disabled={loading || !username || !password}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-2"
              >
                {loading ? 'Signing in...' : 'Sign In'}
              </Button>
            </form>

            <div className="mt-6 pt-6 border-t border-slate-700">
              <p className="text-xs text-slate-400 mb-3 font-semibold">Demo Credentials:</p>
              <div className="space-y-2">
                {demoCredentials.map((cred) => (
                  <div
                    key={cred.username}
                    className="p-3 bg-slate-700 rounded-lg border border-slate-600 text-xs cursor-pointer hover:border-slate-500 transition"
                    onClick={() => {
                      setUsername(cred.username);
                      setPassword(cred.password);
                    }}
                  >
                    <div className="text-slate-300 font-medium">{cred.role}</div>
                    <div className="text-slate-500 mt-1">
                      {cred.username} / {cred.password}
                    </div>
                  </div>
                ))}
              </div>
              
              <Button
                variant="ghost"
                onClick={() => router.push('/signup')}
                className="w-full mt-4 text-slate-300 hover:text-white hover:bg-slate-700"
              >
                Don't have an account? Sign up here
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
