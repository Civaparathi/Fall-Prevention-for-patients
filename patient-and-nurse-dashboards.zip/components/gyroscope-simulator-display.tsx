'use client';

import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { GyroscopeSimulator, type GyroscopeReading } from '@/lib/gyroscope-simulator';
import { AlertTriangle, Activity } from 'lucide-react';

interface GyroscopeSimulatorDisplayProps {
  patientId: string;
  onGaitAnalysis?: (analysis: any) => void;
  onFallDetected?: (fallData: any) => void;
}

export default function GyroscopeSimulatorDisplay({
  patientId,
  onGaitAnalysis,
  onFallDetected,
}: GyroscopeSimulatorDisplayProps) {
  const [isRunning, setIsRunning] = useState(false);
  const [scenario, setScenario] = useState<'normal' | 'unsteady' | 'falling'>('normal');
  const [readings, setReadings] = useState<GyroscopeReading[]>([]);
  const [currentReading, setCurrentReading] = useState<GyroscopeReading | null>(null);
  const [analysis, setAnalysis] = useState<any>(null);
  const [fallDetection, setFallDetection] = useState<any>(null);

  const simulator = new GyroscopeSimulator();

  const startSimulation = async () => {
    setIsRunning(true);
    setReadings([]);
    setAnalysis(null);
    setFallDetection(null);

    const newReadings: GyroscopeReading[] = [];

    // Generate readings over 5 seconds
    for (let i = 0; i < 100; i++) {
      const reading = simulator.generateReading(scenario);
      newReadings.push(reading);
      setCurrentReading(reading);
      setReadings([...newReadings]);

      await new Promise((resolve) => setTimeout(resolve, 50));
    }

    // Analyze gait
    const gaitAnalysis = simulator.analyzeGait(newReadings);
    setAnalysis(gaitAnalysis);

    // Detect fall
    const fall = simulator.detectFall(newReadings);
    setFallDetection(fall);

    // Notify parent
    if (onGaitAnalysis) onGaitAnalysis(gaitAnalysis);
    if (fall.isFalling && onFallDetected) onFallDetected(fall);

    // Save metrics to backend
    if (newReadings.length > 0) {
      const lastReading = newReadings[newReadings.length - 1];
      await fetch('/api/health-metrics', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          patientId,
          timestamp: Date.now(),
          heartRate: 72 + Math.random() * 20,
          oxygenLevel: 98 + Math.random() * 2,
          bloodPressure: '120/80',
          temperature: 37.0 + Math.random() * 0.5,
          gyroscopeData: {
            x: lastReading.x,
            y: lastReading.y,
            z: lastReading.z,
          },
          strideLength: gaitAnalysis.strideLength,
          walkingSpeed: gaitAnalysis.walkingSpeed,
          stepSymmetry: gaitAnalysis.stepSymmetry,
        }),
      });
    }

    setIsRunning(false);
  };

  const stopSimulation = () => {
    setIsRunning(false);
  };

  return (
    <div className="space-y-4">
      {/* Control Panel */}
      <Card className="bg-slate-800 border-slate-700">
        <CardHeader>
          <CardTitle className="text-lg flex items-center gap-2">
            <Activity className="w-5 h-5" />
            Gyroscope Sensor Simulator
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium text-slate-300 block mb-2">
                Simulation Scenario
              </label>
              <div className="space-y-2">
                {(['normal', 'unsteady', 'falling'] as const).map((s) => (
                  <label key={s} className="flex items-center gap-2 cursor-pointer">
                    <input
                      type="radio"
                      value={s}
                      checked={scenario === s}
                      onChange={(e) => setScenario(e.target.value as any)}
                      disabled={isRunning}
                      className="w-4 h-4"
                    />
                    <span className="text-sm text-slate-300 capitalize">{s} Gait</span>
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="text-sm font-medium text-slate-300 block mb-2">Current Reading</label>
              {currentReading ? (
                <div className="space-y-1 text-sm text-slate-400 font-mono">
                  <div>X: {currentReading.x.toFixed(3)}</div>
                  <div>Y: {currentReading.y.toFixed(3)}</div>
                  <div>Z: {currentReading.z.toFixed(3)}</div>
                  <div className="text-xs text-slate-500 mt-2">
                    {currentReading.timestamp}ms
                  </div>
                </div>
              ) : (
                <div className="text-sm text-slate-500">No data yet</div>
              )}
            </div>

            <div>
              <label className="text-sm font-medium text-slate-300 block mb-2">Controls</label>
              <div className="space-y-2">
                <Button
                  onClick={startSimulation}
                  disabled={isRunning}
                  className="w-full bg-green-600 hover:bg-green-700"
                >
                  {isRunning ? 'Running...' : 'Start Simulation'}
                </Button>
                <Button
                  onClick={stopSimulation}
                  disabled={!isRunning}
                  variant="outline"
                  className="w-full bg-transparent"
                >
                  Stop
                </Button>
              </div>
            </div>
          </div>

          {/* Readings Count */}
          {readings.length > 0 && (
            <div className="pt-4 border-t border-slate-700">
              <p className="text-sm text-slate-400">
                Readings collected: <span className="font-semibold text-white">{readings.length}</span>
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Fall Detection Alert */}
      {fallDetection && (
        <Alert
          className={`${
            fallDetection.isFalling
              ? 'border-red-500 bg-red-950'
              : 'border-yellow-500 bg-yellow-950'
          }`}
        >
          <AlertTriangle
            className={`h-4 w-4 ${fallDetection.isFalling ? 'text-red-400' : 'text-yellow-400'}`}
          />
          <AlertDescription
            className={fallDetection.isFalling ? 'text-red-200' : 'text-yellow-200'}
          >
            {fallDetection.description}
            {fallDetection.isFalling && (
              <span className="ml-2 font-semibold">
                (Confidence: {fallDetection.confidenceScore}%)
              </span>
            )}
          </AlertDescription>
        </Alert>
      )}

      {/* Analysis Results */}
      {analysis && (
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-lg">Gait Analysis Results</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <p className="text-sm text-slate-400 mb-1">Stride Length</p>
                <p className="text-2xl font-bold text-white">{analysis.strideLength} cm</p>
              </div>
              <div>
                <p className="text-sm text-slate-400 mb-1">Walking Speed</p>
                <p className="text-2xl font-bold text-white">{analysis.walkingSpeed} m/s</p>
              </div>
              <div>
                <p className="text-sm text-slate-400 mb-1">Step Symmetry</p>
                <p className="text-2xl font-bold text-white">{analysis.stepSymmetry}%</p>
              </div>
              <div>
                <p className="text-sm text-slate-400 mb-1">Gait Quality</p>
                <Badge
                  className={
                    analysis.isNormalGait
                      ? 'bg-green-500/20 text-green-700'
                      : 'bg-red-500/20 text-red-700'
                  }
                >
                  {analysis.isNormalGait ? 'Normal' : 'Abnormal'}
                </Badge>
              </div>
            </div>

            {/* Anomalies */}
            {analysis.anomalies && analysis.anomalies.length > 0 && (
              <div className="mt-4 p-4 bg-red-950 border border-red-500 rounded-lg">
                <p className="text-sm font-semibold text-red-300 mb-2">Detected Anomalies:</p>
                <ul className="space-y-1">
                  {analysis.anomalies.map((anomaly: string, idx: number) => (
                    <li key={idx} className="text-sm text-red-200">
                      • {anomaly}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
