'use client';

import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { AlertTriangle, Heart, TrendingDown, Activity } from 'lucide-react';
import { useState } from 'react';

interface AlertCardProps {
  id: string;
  patientName: string;
  bedNumber: number;
  type: 'fall' | 'gait_anomaly' | 'critical_condition';
  severity: 'low' | 'medium' | 'high' | 'critical';
  message: string;
  timestamp: number;
  acknowledged: boolean;
  acknowledgedBy?: string;
  details?: any;
  onAcknowledge?: (alertId: string, nurseName: string) => void;
}

export default function AlertCard({
  id,
  patientName,
  bedNumber,
  type,
  severity,
  message,
  timestamp,
  acknowledged,
  acknowledgedBy,
  details,
  onAcknowledge,
}: AlertCardProps) {
  const [isAcknowledging, setIsAcknowledging] = useState(false);

  const handleAcknowledge = async () => {
    setIsAcknowledging(true);
    if (onAcknowledge) {
      onAcknowledge(id, 'Dr. Nurse');
    }
  };

  const severityStyles = {
    low: 'border-l-4 border-blue-500 bg-blue-950',
    medium: 'border-l-4 border-yellow-500 bg-yellow-950',
    high: 'border-l-4 border-orange-500 bg-orange-950',
    critical: 'border-l-4 border-red-500 bg-red-950',
  };

  const severityBadgeStyles = {
    low: 'bg-blue-500/20 text-blue-300',
    medium: 'bg-yellow-500/20 text-yellow-300',
    high: 'bg-orange-500/20 text-orange-300',
    critical: 'bg-red-500/20 text-red-300',
  };

  const typeIcons = {
    fall: <AlertTriangle className="w-5 h-5" />,
    gait_anomaly: <Activity className="w-5 h-5" />,
    critical_condition: <Heart className="w-5 h-5" />,
  };

  const typeLabels = {
    fall: 'Fall Detected',
    gait_anomaly: 'Gait Anomaly',
    critical_condition: 'Critical Condition',
  };

  return (
    <Card className={`${severityStyles[severity]} border border-slate-700`}>
      <CardContent className="pt-6">
        <div className="space-y-4">
          {/* Header */}
          <div className="flex items-start justify-between">
            <div className="flex items-start gap-3 flex-1">
              <div className={`text-${severity === 'critical' ? 'red' : 'yellow'}-400 mt-1`}>
                {typeIcons[type]}
              </div>
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <h3 className="font-bold text-white text-lg">{patientName}</h3>
                  <Badge variant="outline" className="text-xs">
                    Bed {bedNumber}
                  </Badge>
                </div>
                <p className="text-sm text-slate-300 mb-2">{message}</p>
                <p className="text-xs text-slate-400">
                  {new Date(timestamp).toLocaleTimeString()}
                </p>
              </div>
            </div>
            <Badge className={`${severityBadgeStyles[severity]} font-semibold`}>
              {severity.toUpperCase()}
            </Badge>
          </div>

          {/* Alert Type */}
          <div className="flex items-center gap-2 py-2 px-3 bg-slate-700/50 rounded">
            <span className="text-xs font-medium text-slate-300">Type:</span>
            <Badge variant="secondary" className="text-xs">
              {typeLabels[type]}
            </Badge>
          </div>

          {/* Details */}
          {details && (
            <div className="space-y-2 bg-slate-700/30 p-3 rounded text-xs text-slate-300">
              {details.fallDetected && (
                <div className="flex justify-between">
                  <span>Fall Detected:</span>
                  <span className="font-semibold text-red-300">Yes</span>
                </div>
              )}
              {details.heartRate && (
                <div className="flex justify-between">
                  <span>Heart Rate:</span>
                  <span className="font-semibold text-white">{details.heartRate} BPM</span>
                </div>
              )}
              {details.oxygenLevel && (
                <div className="flex justify-between">
                  <span>Oxygen Level:</span>
                  <span className="font-semibold text-white">{details.oxygenLevel}%</span>
                </div>
              )}
              {details.strideLength && (
                <div className="flex justify-between">
                  <span>Stride Length:</span>
                  <span className="font-semibold text-white">{details.strideLength} cm</span>
                </div>
              )}
              {details.walkingSpeed && (
                <div className="flex justify-between">
                  <span>Walking Speed:</span>
                  <span className="font-semibold text-white">{details.walkingSpeed} m/s</span>
                </div>
              )}
              {details.stepSymmetry && (
                <div className="flex justify-between">
                  <span>Step Symmetry:</span>
                  <span className="font-semibold text-white">{details.stepSymmetry}%</span>
                </div>
              )}
              {details.inconsistencies && details.inconsistencies.length > 0 && (
                <div className="mt-2 pt-2 border-t border-slate-600">
                  <p className="text-slate-400 mb-1">Inconsistencies:</p>
                  <ul className="space-y-1">
                    {details.inconsistencies.map((issue: string, idx: number) => (
                      <li key={idx} className="text-red-300">
                        • {issue}
                      </li>
                    ))}
                  </ul>
                </div>
              )}
            </div>
          )}

          {/* Status */}
          {acknowledged && (
            <div className="flex items-center gap-2 py-2 px-3 bg-green-950/50 border border-green-500/30 rounded text-xs text-green-300">
              <span>✓ Acknowledged by {acknowledgedBy || 'Nurse'}</span>
            </div>
          )}

          {/* Actions */}
          {!acknowledged && (
            <Button
              onClick={handleAcknowledge}
              disabled={isAcknowledging}
              className="w-full bg-green-600 hover:bg-green-700 text-white font-semibold"
            >
              {isAcknowledging ? 'Acknowledging...' : 'Acknowledge & Mark Stable'}
            </Button>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
