'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Heart, Wind, Zap } from 'lucide-react';

interface HealthMetrics {
  heartRate: number;
  oxygenLevel: number;
  temperature: number;
  bloodPressure: string;
  strideLength: number;
  walkingSpeed: number;
  stepSymmetry: number;
}

interface PatientHealthDisplayProps {
  metrics: HealthMetrics;
  isAlert?: boolean;
}

export default function PatientHealthDisplay({ metrics, isAlert }: PatientHealthDisplayProps) {
  const getHeartRateStatus = (hr: number) => {
    if (hr < 60 || hr > 100) return 'warning';
    return 'success';
  };

  const getOxygenStatus = (o2: number) => {
    if (o2 < 95) return 'error';
    if (o2 < 97) return 'warning';
    return 'success';
  };

  const getTemperatureStatus = (temp: number) => {
    if (temp < 36.5 || temp > 37.5) return 'warning';
    return 'success';
  };

  const statusColors = {
    success: 'bg-green-500/20 text-green-700 border-green-500/50',
    warning: 'bg-yellow-500/20 text-yellow-700 border-yellow-500/50',
    error: 'bg-red-500/20 text-red-700 border-red-500/50',
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {/* Heart Rate */}
      <Card className={`border-l-4 ${isAlert ? 'border-red-500' : 'border-slate-700'} bg-slate-800`}>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
            <Heart className="w-4 h-4" />
            Heart Rate
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-white">{metrics.heartRate}</div>
          <p className="text-xs text-slate-400 mt-1">BPM</p>
          <Badge className={`mt-2 ${statusColors[getHeartRateStatus(metrics.heartRate)]}`}>
            {getHeartRateStatus(metrics.heartRate) === 'success' ? 'Normal' : 'Elevated'}
          </Badge>
        </CardContent>
      </Card>

      {/* Oxygen Level */}
      <Card
        className={`border-l-4 ${isAlert ? 'border-red-500' : 'border-slate-700'} bg-slate-800`}
      >
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
            <Wind className="w-4 h-4" />
            Oxygen Level
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-white">{metrics.oxygenLevel}</div>
          <p className="text-xs text-slate-400 mt-1">SpO2 %</p>
          <Badge className={`mt-2 ${statusColors[getOxygenStatus(metrics.oxygenLevel)]}`}>
            {getOxygenStatus(metrics.oxygenLevel) === 'success' ? 'Normal' : 'Low'}
          </Badge>
        </CardContent>
      </Card>

      {/* Temperature */}
      <Card className={`border-l-4 ${isAlert ? 'border-red-500' : 'border-slate-700'} bg-slate-800`}>
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-slate-300 flex items-center gap-2">
            <Zap className="w-4 h-4" />
            Temperature
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-white">{metrics.temperature.toFixed(1)}</div>
          <p className="text-xs text-slate-400 mt-1">°C</p>
          <Badge className={`mt-2 ${statusColors[getTemperatureStatus(metrics.temperature)]}`}>
            {getTemperatureStatus(metrics.temperature) === 'success' ? 'Normal' : 'Abnormal'}
          </Badge>
        </CardContent>
      </Card>

      {/* Blood Pressure */}
      <Card className="border-l-4 border-slate-700 bg-slate-800">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-slate-300">Blood Pressure</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-white">{metrics.bloodPressure}</div>
          <p className="text-xs text-slate-400 mt-1">mmHg</p>
          <Badge variant="secondary" className="mt-2">
            Monitor
          </Badge>
        </CardContent>
      </Card>

      {/* Stride Length */}
      <Card className="border-l-4 border-slate-700 bg-slate-800">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-slate-300">Stride Length</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-white">{metrics.strideLength}</div>
          <p className="text-xs text-slate-400 mt-1">cm</p>
          <Badge variant="secondary" className="mt-2">
            Analysis
          </Badge>
        </CardContent>
      </Card>

      {/* Walking Speed */}
      <Card className="border-l-4 border-slate-700 bg-slate-800">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm font-medium text-slate-300">Walking Speed</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-3xl font-bold text-white">{metrics.walkingSpeed}</div>
          <p className="text-xs text-slate-400 mt-1">m/s</p>
          <Badge variant="secondary" className="mt-2">
            Gait
          </Badge>
        </CardContent>
      </Card>
    </div>
  );
}
