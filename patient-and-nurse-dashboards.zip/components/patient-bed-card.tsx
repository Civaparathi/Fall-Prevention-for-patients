'use client';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Heart, User } from 'lucide-react';

interface PatientBedCardProps {
  patientId: string;
  patientName: string;
  bedNumber: number;
  status: 'stable' | 'critical' | 'recovering';
  hasActiveAlert?: boolean;
  alertCount?: number;
  lastUpdate?: number;
}

export default function PatientBedCard({
  patientId,
  patientName,
  bedNumber,
  status,
  hasActiveAlert,
  alertCount = 0,
  lastUpdate,
}: PatientBedCardProps) {
  const statusColors = {
    stable: 'bg-green-950 border-green-500',
    critical: 'bg-red-950 border-red-500',
    recovering: 'bg-yellow-950 border-yellow-500',
  };

  const statusBadgeColors = {
    stable: 'bg-green-500/20 text-green-300',
    critical: 'bg-red-500/20 text-red-300',
    recovering: 'bg-yellow-500/20 text-yellow-300',
  };

  return (
    <Card className={`border-l-4 ${statusColors[status]} border border-slate-700`}>
      <CardHeader className="pb-3">
        <div className="flex items-start justify-between">
          <div>
            <CardTitle className="text-lg flex items-center gap-2">
              <span className="text-2xl font-bold text-white">Bed {bedNumber}</span>
            </CardTitle>
            <p className="text-sm text-slate-300 mt-1 flex items-center gap-2">
              <User className="w-4 h-4" />
              {patientName}
            </p>
          </div>
          <Badge className={statusBadgeColors[status]}>{status.toUpperCase()}</Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {/* Alert Status */}
          {hasActiveAlert && (
            <div className="flex items-center gap-2 py-2 px-3 bg-red-500/20 border border-red-500/50 rounded text-xs text-red-300 font-semibold">
              <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse"></div>
              {alertCount} Active Alert{alertCount !== 1 ? 's' : ''}
            </div>
          )}

          {/* Last Update */}
          {lastUpdate && (
            <p className="text-xs text-slate-400">
              Last update: {new Date(lastUpdate).toLocaleTimeString()}
            </p>
          )}

          {!hasActiveAlert && (
            <p className="text-xs text-slate-400 text-center py-2">All parameters normal</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
